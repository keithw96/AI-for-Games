#pragma once 

#include <SFML/Graphics.hpp>
#include "Player.h"
#include "WandererAlien.h"

class Game
{
public:
	Game();
	Player m_player;
	WandererAlien m_wanderer;
	void run();

protected:
	void update();
	void render();
	void processEvents();

	sf::RenderWindow m_window;

private: 
	sf::Sprite m_background;
	sf::Texture m_txtBackground;
};