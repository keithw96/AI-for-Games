#include "Game.h"

Game::Game()
	: m_window(sf::VideoMode(1440, 810, 32), "Lab1", sf::Style::Default)
{
	m_txtBackground.loadFromFile("resource/space_background.png");
	m_background.setTexture(m_txtBackground);
	m_background.setTextureRect(sf::IntRect(0,0, m_window.getSize().x, m_window.getSize().y));
	m_background.setPosition(0, 0);

	m_player.init();
	m_wanderer.init();
}

void Game::run()
{
	while (m_window.isOpen())
	{
		processEvents();
		update();
		render();
	}
}

void Game::processEvents()
{
	sf::Event event;
	while (m_window.pollEvent(event))
	{
		if (event.type == sf::Event::Closed)
		{
			m_window.close();
		}
	}
}

void Game::update()
{
	m_player.update(m_window);
	m_wanderer.update();
}

void Game::render()
{
	m_window.draw(m_background);
	m_player.render(m_window);
	m_wanderer.render(m_window);

	m_window.display();
}