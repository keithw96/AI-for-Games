#include "Player.h"
#include <math.h>
#include <iostream>

void Player::init()
{
	m_position = sf::Vector2f(100, 400);
	m_velocity = 0;
	m_rotation = 0;
	m_velocity = 5;

	m_texture.loadFromFile("resource/Player.png");
	m_sprite.setTexture(m_texture);
	m_sprite.setPosition(m_position.x, m_position.y);
	m_sprite.setRotation(m_rotation);
	m_sprite.setOrigin(m_sprite.getTextureRect().width / 2, m_sprite.getTextureRect().height / 2);
}

void Player::render(sf::RenderWindow &window)
{
	window.draw(m_sprite);
}

void Player::update(sf::RenderWindow &window)
{
	handleInput();

	m_sprite.setPosition(m_position.x, m_position.y);
	m_sprite.setRotation(m_rotation);

	worldBoundary(window);
}

void Player::handleInput()
{
	if (sf::Keyboard::isKeyPressed(m_keyboard.Up))
	{
		if (m_velocity < 10)
		{
			m_velocity += 0.5;
		}

		m_position.x += sin((3.14159265 / 180) * m_rotation) * 0.5;
		m_position.y -= cos((3.14159265 / 180) * m_rotation) * 0.5;

	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
	{
		if (m_velocity > 0)
		{
			m_velocity -= 0.2;
		}
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
	{
		m_rotation += 0.2;

		if (m_rotation == 360.0)
		{
			m_rotation = 0;
		}
	}

	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
	{
		m_rotation -= 0.5;

		if (m_rotation == 0)
		{
			m_rotation = 359.0;
		}
	}
}

void Player::worldBoundary(sf::RenderWindow &window)
{
	if (m_position.x > window.getSize().x)
	{
		m_position.x = 0 - m_sprite.getTextureRect().width;
	}

	if (m_position.x + m_sprite.getTextureRect().width < 0)
	{
		m_position.x = window.getSize().x;
	}

	if (m_position.y + m_sprite.getTextureRect().height < 0)
	{
		m_position.y = window.getSize().y;
	}

	if (m_position.y > window.getSize().y)
	{
		m_position.y = 0;
	}
}

