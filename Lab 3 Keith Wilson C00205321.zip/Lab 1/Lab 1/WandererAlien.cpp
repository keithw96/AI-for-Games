#include "WandererAlien.h"
#include <iostream>

void WandererAlien::init()
{
	m_position = sf::Vector2f(800, 400);

	int randX = rand() % 1440;
	int randY = rand() % 810;

	m_destination = sf::Vector2f(randX, randY);

	m_velocity = 0;
	m_rotation = 0;
	m_velocity = 5;

	m_texture.loadFromFile("resource/wandererAlien.png");
	m_sprite.setTexture(m_texture);
	m_sprite.setPosition(m_position.x, m_position.y);
	m_sprite.setRotation(m_rotation);
	m_sprite.setOrigin(m_sprite.getTextureRect().width / 2, m_sprite.getTextureRect().height / 2);
}

void WandererAlien::update()
{
	handleMovement();

	m_sprite.setPosition(m_position);
	m_sprite.setRotation(m_rotation);

	std::cout << m_destination.x << std::endl;
	std::cout << m_destination.y << std::endl;
}

void WandererAlien::render(sf::RenderWindow &window)
{
	window.draw(m_sprite);
}

void WandererAlien::handleMovement()
{
	if (m_position.x < m_destination.x)
	{
		m_position.x += 0.5;
	}

	if (m_position.x > m_destination.x)
	{
		m_position.x -= 0.5;
	}

	if (m_position.y < m_destination.y)
	{
		m_position.y += 0.5;
	}

	if (m_position.y > m_destination.y)
	{
		m_position.y -= 0.5;
	}

	if (m_position == m_destination) 
	{
		int randX = rand() % 1440;
		int randY = rand() % 810;

		m_destination = sf::Vector2f(randX, randY);
	}
}