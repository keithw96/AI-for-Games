#pragma once
#include <SFML/Graphics.hpp>


class Player
{
public:
	float m_velocity;
	float m_rotation;

	sf::Vector2f m_position;

	sf::Keyboard m_keyboard;

	void init();
	void update(sf::RenderWindow &window);
	void render(sf::RenderWindow &window);
	void handleInput();
	void worldBoundary(sf::RenderWindow &window);
private:
	sf::Sprite m_sprite;
	sf::Texture m_texture;
};