#pragma once
#include <SFML/Graphics.hpp>

class WandererAlien
{
public:
	float m_velocity;
	float m_rotation;

	sf::Vector2f m_position;
	sf::Vector2f m_destination;

	sf::Keyboard m_keyboard;

	void init();
	void update();
	void render(sf::RenderWindow &window);
	void handleMovement();
private:
	sf::Sprite m_sprite;
	sf::Texture m_texture;
};